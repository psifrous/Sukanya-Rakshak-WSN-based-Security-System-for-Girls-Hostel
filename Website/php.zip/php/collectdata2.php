<?php
$servername = "localhost";
$username = "pi";
$password = "raspberry";
$dbname = "temps";

$DID = $_GET['DID'];
echo $DID;
$Distance = $_GET['Distance'];
echo $Distance;

$conn=mysqli_connect("localhost","pi","raspberry");

if(!$conn)
{
die('Could not connect: ' . mysqli_error());
}
mysqli_select_db($conn,$dbname);

$TID = rand(999,9999);
$sql = "INSERT INTO dummmyLog(TID,iTime,iDate,DID,Distance)VALUES('$TID',NOW(),NOW(),'$DID','$Distance')";

$result = mysqli_query($conn,$sql);

if(!result)
{
die('Invalid query: ' . mysqli_error());
}

echo "<h1>The data has been sent!</h1>";
mysql_close($conn);

?>

