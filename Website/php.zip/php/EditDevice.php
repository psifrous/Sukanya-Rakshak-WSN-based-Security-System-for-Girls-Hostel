<?php
include 'dbconnection.php';

$DID = $_REQUEST['DID'];

$sql1 = "SELECT * from dummmyLocRec where DID=$DID";

if($result = $mysqli->query($sql1))
{
	$row = $result->fetch_assoc();
	$Loc = $row["Location"];
}
else{
	die('Invalid query: ' . mysqli_error());
}

if($_POST){
	$Loc= $_POST['locationName'];

	echo $sql = "UPDATE dummmyLocRec SET Location = '$Loc' WHERE DID = $DID";
	
	if($mysqli->query($sql))
	{
		header("Location: ListDevices.php");		
	}
	else{
		die('Invalid query: ' . mysqli_error());	
	}
}

include_once('header.php');
?>
<head>
<title>Edit <?php echo $DID; ?></title></head>
<div class=container>
	<h1>Edit the Device <?php echo $DID ?></h1>
	<form class="form-horizontal" method="POST" >
		<div class="form-group">
			<label class="control-label col-sm-2" for="locationName">Location name:</label>
			<div class="col-sm-10">
    				<input type="text" class="form-control" id="locationName" value="<?php echo $Loc; ?>">		
			</div>
		</div>
		<div class="col-sm-offset-2 col-sm-10">
			<button type="submit"  class="btn btn-warning">Change</button>
		</div>
	</form>

</div>
<br>
<?php
/* close connection */
$mysqli->close();
include_once('footer.php');
?>
