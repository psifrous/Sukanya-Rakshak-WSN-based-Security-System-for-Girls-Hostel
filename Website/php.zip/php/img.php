<?php
include 'dbconnection.php';

if(isset($_FILE['uploadimager']))
{
    
    $filename=$_FILES['uploadimage']['name'];
    $target_dir="images//photos//";
    $target_file=$target_dir.basename($filename);
    if( $_FILES['uploadimage']['name'] != "" )
     {
      move_uploaded_file($_FILES["uploadimage"]["tmp_name"],$target_file);
	echo 'FILE:'.$target_file;
     }
    else
     {
      die("No file specified!");
     }
}

?>
<form action="" method="POST">
<div class="form-group">
		<label class="control-label col-sm-2" for="uploadimage">Image:</label>
		<div class="col-sm-10">	
			<input name="uploadimage" id="uploadimage" type="file">	
		</div>
	</div>	
	
	<div class="col-sm-offset-2 col-sm-10">
		<button type="submit" class="btn btn-primary btn-lg" name="submit" id="submit">Submit</button>
	</div>
	
</form>