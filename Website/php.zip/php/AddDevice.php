<?php 
include_once('header.php');

	if($_POST){
	include 'dbconnection.php';
	$a= $_POST['ipa'];
	$b= $_POST['locationName'];
	$c= $_POST['deviceId'];
	$sql = "INSERT INTO `dummmyLocRec` (`Location`, `DID`, `IPA`) VALUES ('$b', '$c', '$a')";
	if($mysqli->query($sql)){
		echo "Data Inserted";
		header("Location: AddDevice.php");
	}
}
?>


<div class=container>
	<center>
	<h1>Add a New Device</h1>
	</center>
	<form class="form-horizontal" method="POST" action="">  
		<div class="form-group">
		      <label class="control-label col-sm-2" for="ipa">IP Address:</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="ipa" name="ipa">
			</div>
		</div>
	  	<div class="form-group">
		      <label class="control-label col-sm-2" for="locationName">Location Name:</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="locationName" name="locationName">
			</div>
		</div>
	 	<div class="form-group">
		      <label class="control-label col-sm-2" for="deviceId">Device ID:</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="deviceId" name="deviceId">
			</div>
		</div>
		<div class="col-sm-offset-2 col-sm-10">
			<button type="submit"  class="btn btn-warning"> Add </button>
			<a href="AddDevice.php" class="btn btn-danger" role="button">Reset</a>
		</div>
		
	</form>
</div>
<br>
<footer class="container-fluid text-center">
<p>Website designed by Shreyans Jain</p>
</footer>
</div>
</body>


