<?php
$servername = "localhost";
$username = "pi";
$password = "raspberry";
$dbname = "temps";

$DID = $_GET['DID'];
echo $DID;
$IPA = $_GET['IPA'];
echo $IPA;

$conn=mysqli_connect("localhost","pi","raspberry");
if(!$conn)
{
die('Could not connect: ' . mysqli_error());
}
mysqli_select_db($conn,$dbname);

//die;
echo $sql = "DELETE FROM dummmyLocRec WHERE DID = $DID AND IPA = '$IPA'";

$result = mysqli_query($conn,$sql);

if(!result)
{
die('Invalid query: ' . mysqli_error());
}
else{
header("Location: ListDevices.php");
}

?>
<input type="button" value="Home" onclick="window.location.href='index.php'" />

<?php


/* close connection */
$mysqli->close();

?>