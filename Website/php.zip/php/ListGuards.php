<?php
include 'dbconnection.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Guards Detail</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
 
/* Set height of the grid so .sidenav can be 100% (adjust as needed) */
.row.content {height: 450px}
 
.sidenav {
padding-top: 20px;
background-color: #f1f1f1;
height: 100%;
}
 
footer {
background-color: #555;
color: white;
padding: 15px;
}
 
/* On small screens, set height to 'auto' for sidenav and grid */
@media screen and (max-width: 767px) {
.sidenav {
height: auto;
padding: 15px;
}
.row.content {height:auto;}
}
</style>
</head>
<body>
 <div class="container-fluid">
<nav class="navbar navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php">Sukanya Rakshak</a>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="SeeDetails.php">Logs</a></li>
      <li><a href="ListDevices.php">See Devices</a></li>
      <li><a href="AddDevice.php">Add Device</a></li>
      <li><a href="NewShift.php">New Shift</a></li>
      <li><a href="ListGuards.php">Guard Details</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
</ul>
</div>
</div>
</nav>
 <center>
<div style="background:#118888;color:white" class="jumbotron">
	<h2>Sukanya Rakshak </h2>
	<h4>Sukanya Rakshak </h4>
</div>
</center>

<div class="container-fluid text-center">
<center>
	<h1>List of Guards</h1>
<center>

</div>

<div class="container">
<form class="form-horizontal" action="" method="POST">
	<div class="form-group">
		<label class="control-label col-sm-2" for="shift">Shift:</label>
		<div class="col-sm-2">
    			<select class="form-control" name=shift>
				<option value="None">-</option>
				<option value="Morning">Morning</option>
				<option value="Evening">Evening</option>
			</select> 		
		</div>
	
		<label class="control-label col-sm-2" for="date">Date:</label>
		<div class="col-sm-2">
			<input type="date" name='gdate' class="form-control" id="gdate" >
		</div>
		
		<div class="col-sm-offset-2 col-sm-2">
			<button type="submit" class="btn btn-warning btn-lg" name="submit" id="submit">Submit</button>
		</div>
		
	</div>
</form>

<?php
if($_POST){
	$shift = $_POST['shift'];
	$date  = $_POST['gdate'];

	$sql = "SELECT * FROM GuardLog where Shift='$shift' AND Date='$date'";
	if($result=$mysqli->query($sql)){
  ?>
<table class="table table-striped">
	<thead >
        	<tr>
                	<th>Guard Name</th>
	                <th>Guard #</th>
			<th>Location</th>
	                <th>Mobile #</th>
	                <th>Email ID</th>
		</tr>

        </thead>
        <tbody><?php
		while($row = $result->fetch_assoc()){
		?>
		<tr>
			<td><?php echo $row['Name']; ?></td>
            		<td><?php echo $row['GuardID'];  ?></td>
            		<td><?php echo $row['Location'];  ?></td>
			<td><?php echo $row['Mobile'];  ?></td>
            		<td><?php echo $row['EmailID'];  ?></td>
            	</tr>
	</tbody>
</table>
	<?php	}
	}
	else{
		die('Invalid query: ' . mysqli_error());
	}	
}
include_once('footer.php');
?>