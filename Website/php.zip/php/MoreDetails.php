<?php
include 'dbconnection.php';
$TID = $_REQUEST['TID'];

$sql = "SELECT * FROM IntruderLog WHERE TID=$TID";

if($result=$mysqli->query($sql)){

	$row = $result->fetch_assoc();
	$TTime=$row["TTime"];
	$TDate=$row["TDate"];
	$ETime=$row["ETime"];
	$EDate=$row["EDate"];
	$Loc=$row["Location"];
	$DID=$row["DID"];
	$Dist=$row["Distance"];
	$status=$row["Status"];
	$Details=$row["Details"];
	$LocImage=$row["LocImage"];
	 
}
else{
	die('Invalid Query: '. mysqli_error());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Details of <?php echo $TID; ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
 
/* Set height of the grid so .sidenav can be 100% (adjust as needed) */
.row.content {height: 450px}
 
.sidenav {
padding-top: 20px;
background-color: #f1f1f1;
height: 100%;
}
 
footer {
background-color: #555;
color: white;
padding: 15px;
}
 
/* On small screens, set height to 'auto' for sidenav and grid */
@media screen and (max-width: 767px) {
.sidenav {
height: auto;
padding: 15px;
}
.row.content {height:auto;}
}
</style>
</head>
<body>
  <div class="container-fluid">
<nav class="navbar navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php">Sukanya Rakshak</a>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="SeeDetails.php">Logs</a></li>
      <li><a href="ListDevices.php">See Devices</a></li>
      <li><a href="AddDevice.php">Add Device</a></li>
      <li><a href="NewShift.php">New Shift</a></li>    
      <li><a href="ListGuards.php">Guard Details</a></li>  
</ul>
<ul class="nav navbar-nav navbar-right">
<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
</ul>
</div>
</div>
</nav>
 
<center>
<div style="background:#118888;color:white" class="jumbotron">
	<h2>Sukanya Rakshak </h2>
	<h4>Sukanya Rakshak </h4>
</div>
</center>


<div class="container-fluid text-center">
<h1> More Details on Transaction ID: <?php echo $TID; ?> </h1>

</div>

<div class=container>
<form class="form-horizontal">
	<div class="form-group">
		<label class="control-label col-sm-2" for="LOC">Location:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="LOC" placeholder="<?php echo $Loc; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="TTime">Transaction Time:</label>
		<div class="col-sm-4">
    			<input type="text" class="form-control" id="TTime" placeholder="<?php echo $TTime; ?>">		
		</div>
		<label class="control-label col-sm-2" for="TDate">Transaction Date:</label>
		<div class="col-sm-4">
    			<input type="text" class="form-control" id="TDate" placeholder="<?php echo $TDate; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="ETime">Escalated Time:</label>
		<div class="col-sm-4">
    			<input type="text" class="form-control" id="ETime" placeholder="<?php echo $ETime; ?>">		
		</div>
	
		<label class="control-label col-sm-2" for="EDate">Escalated Date:</label>
		<div class="col-sm-4">
    			<input type="text" class="form-control" id="EDate" placeholder="<?php echo $EDate; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="DID">Device ID:</label>
		<div class="col-sm-4">
    			<input type="text" class="form-control" id="DID" placeholder="<?php echo $DID; ?>">		
		</div>

		<label class="control-label col-sm-2" for="Distance">Distance:</label>
		<div class="col-sm-4">
    			<input type="text" class="form-control" id="Distance" placeholder="<?php echo $Dist; ?>">		
		</div>
	</div>	

	<div class="form-group">
		<label class="control-label col-sm-2" for="status">Status:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="status" placeholder="<?php echo $status; ?>">		
		</div>
	</div>	

	<div class="form-group">
		<label class="control-label col-sm-2" for="detailfield">Details:</label>
		<div class="col-sm-10">	
			<input type="text" class="form-control" name="detailfield" placeholder="<?php echo $Details; ?>" > 		
		</div>
	</div>	

	<div class="form-group">
		<label class="control-label col-sm-2" for="detailfield">Location Image:</label>
		<div class="col-sm-10">	
		<center>
			<img src="/var/www/html/php/images/photos/<?php echo $LocImage;?>" width="175" height="200" />		
		</center>
	</div>	

	
</form>
</div>
</div>
<?php
$mysqli->close();
include_once('footer.php');
?>