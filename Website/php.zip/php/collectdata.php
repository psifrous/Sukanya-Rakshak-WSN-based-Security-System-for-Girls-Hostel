
<?php
include 'dbconnection.php';

$DID = $_GET['DID'];
echo $DID;
$Distance = $_GET['Distance'];
echo $Distance;

$TID = rand(999,9999);

$sql1 = "INSERT INTO dummmyLog(TID,iTime,iDate,DID,Distance)VALUES('$TID',NOW(),NOW(),'$DID','$Distance')";
if($result1 = $mysqli->query($sql1))
{
	echo "<br><h1>The data has been sent!</h1><br>";
}
else{
	die('Invalid query: ' . mysqli_error());
}

$sql2 = "SELECT Location FROM dummmyLocRec where DID=$DID";
if($result2 = $mysqli->query($sql2))
{
	$row = $result2->fetch_assoc();
	$Loc = $row["Location"];
	echo $Loc;
}
else{
	die('Invalid query: ' . mysqli_error());
}

$status="Pending";
$details="None";

$sql3 = "INSERT INTO IntruderLog(TID,TTime,TDate,Location,DID,Distance,Status,Details) VALUES('$TID',NOW(),NOW(),'$Loc','$DID','$Distance','$status','$details')";
if($result3 = $mysqli->query($sql3)){
	echo "<br><h1>The data has been inserted into IntruderLog!</h1><br>";
}
else{
	die('Invalid query: ' . mysqli_error());
}
mysql_close($conn);

?>
