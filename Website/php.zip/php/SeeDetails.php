<?php
include_once('header.php');
?>
<title>Logs</title>
<?php
include 'dbconnection.php';

$query = "SELECT * FROM IntruderLog";

if ($result = $mysqli->query($query)) {

    ?>
    <center>
	<h1>Logs</h1>
    </center>
    <table class="table table-striped">
        <thead >
            <tr>
                <th>TID</th>
                <th>LOC</th>
		<th>DID</th>
		<th>Status</th>
		<th>On Click</th>
            </tr>

        </thead>
        <tbody>


<?php 
	while ($row = $result->fetch_assoc()) {
?>
	<tr>
		<td><?php echo $row["TID"]; ?></td>
            	<td><?php echo $row["Location"];  ?></td>
		<td><?php echo $row["DID"]; ?></td>
            	<td><?php echo $row["Status"]; ?></td>
	    	<td><a href="MoreDetails.php?TID=<?php echo $row["TID"] ?>" class="btn btn-warning" role="button">More</a></td>
        </tr>
<?php
	}
?>
	</tbody>
	</table>
<?php
	$result->free();
}
else{
	echo " There is some error!";
}
/* close connection */
$mysqli->close();


include_once('footer.php');
?>
