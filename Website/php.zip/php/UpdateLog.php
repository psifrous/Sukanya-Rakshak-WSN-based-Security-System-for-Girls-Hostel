<?php
include 'dbconnection.php';

$TID = $_REQUEST['TID'];
$sql = "SELECT * FROM IntruderLog WHERE TID=$TID";
if ($result = $mysqli->query($sql)) {
	$row = $result->fetch_assoc();
	$TTime=$row["TTime"];
	$TDate=$row["TDate"];
	$ETime=$row["ETime"];
	$EDate=$row["EDate"];
	$Loc=$row["Location"];
	$DID=$row["DID"];
	$Dist=$row["Distance"];
	$status=$row["Status"];
	$Details=$row["Details"];
  }
 else{	
    die('Invalid query 000: ' . mysqli_error());
 }


if(isset($_POST['submit']))
{
    
    $filename=$_FILES['uploadimage']['name'];
    $temp_name=$_FILES['uploadimage']['temp_name'];
	if(isset($filename)){
	echo "Hello 123";
	}


	
    $target_dir="images\\photos\\";
    $target_file=$target_dir.basename($filename);
    if( $_FILES['uploadimage']['name'] != "" )
     {
      $upload = move_uploaded_file($temp_name,"$target_file");
	if(isset($upload)){
		echo "Image Uploaded";
		}else{
			echo "not Uploaded";
}

	echo 'FILE:'.$target_file;
     }
    else
     {
      die("No file specified!");
     }

     $errorMessage = "";  
     $fpic=$filename;

    if($errorMessage != "" ) 
     {
       echo "<p class='message'>" .$errorMessage. "</p>" ;
    }
    else
    {

  //new code
  $stat= $_POST['statusField'];
  $Deat= $_POST['detailfield'];
  //$img= $_FILES['uploadimage']['name'];
	
	if("Esclate"==$stat){
		$sql = "UPDATE IntruderLog SET ETime=NOW(), EDate=NOW(), Status='$stat', Details='$Deat', LocImage='$fpic' WHERE TID='$TID'";
		if($mysqli->query($sql)){
		echo 'DDDD'.$filename;	
		//header("Location: index.php");		
		}
		else{
			die('Invalid query1: ' . mysqli_error());
		}	
	}
	else{
		$sql = "UPDATE IntruderLog SET DTime=NOW(), DDate=NOW(), Status='$stat', Details='$Deat', LocImage='$fpic' WHERE TID='$TID'";
		if($mysqli->query($sql)){
			echo 'FFF'.$filename;	
			//header("Location: index.php");		
		}
		else{
			die('Invalid query2: ' . mysqli_error());
		}	
	}
   //end of new code
   echo "Record updated Successfully";
  }
} //end of outer
?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Update <?php echo $TID; ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
 
/* Set height of the grid so .sidenav can be 100% (adjust as needed) */
.row.content {height: 450px}
 
.sidenav {
padding-top: 20px;
background-color: #f1f1f1;
height: 100%;
}
 
footer {
background-color: #555;
color: white;
padding: 15px;
}
 
/* On small screens, set height to 'auto' for sidenav and grid */
@media screen and (max-width: 767px) {
.sidenav {
height: auto;
padding: 15px;
}
.row.content {height:auto;}
}
</style>
</head>
<body>
 
<nav class="navbar navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php">Sukanya Rakshak</a>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="SeeDetails.php">Logs</a></li>
      <li><a href="ListDevices.php">See Devices</a></li>
      <li><a href="AddDevice.php">Add Device</a></li>
      <li class="active"><a href="UpdateLog.php?TID=<?php echo $row["TID"] ?>">Update <?php echo $row["TID"] ?></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
</ul>
</div>
</div>
</nav>
 
<div class="container-fluid text-center">


</div>

<div class=container>

<form enctype="multipart/form-data" data-toggle="validator" class="form-horizontal" id="form_members" role="form" action="" method="POST">
	<div class="form-group">
		<label class="control-label col-sm-2" for="TID">Transaction ID:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="TID" placeholder="<?php echo $TID; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="LOC">Location:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="LOC" placeholder="<?php echo $Loc; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="TTime">Transaction Time:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="TTime" placeholder="<?php echo $TTime; ?>">		
		</div>
	</div>	
	<div class="form-group">
		<label class="control-label col-sm-2" for="TDate">Transaction Date:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="TDate" placeholder="<?php echo $TDate; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="ETime">Escalated Time:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="ETime" placeholder="<?php echo $ETime; ?>">		
		</div>
	</div>	
	<div class="form-group">
		<label class="control-label col-sm-2" for="EDate">Escalated Date:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="EDate" placeholder="<?php echo $EDate; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="DID">Device ID:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="DID" placeholder="<?php echo $DID; ?>">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="Distance">Distance:</label>
		<div class="col-sm-10">
    			<input type="text" class="form-control" id="Distance" placeholder="<?php echo $Dist; ?>">		
		</div>
	</div>	

	<div class="form-group">
		<label class="control-label col-sm-2" for="statusField">Status<label data-toggle="tooltip" title="Escalate if Necessary"><font color="red">*</font></label>:</label>
		<div class="col-sm-10">
			<select class="form-control" name=statusField>
				<?php
				if($status == "Pending"){?>
				<option value="Esclate">Escalate</option>
				<option value="Done">Done</option>
				<?php
				}
				elseif($status == "Esclate"){?>
				<option value="Done">Done</option>
				<?php } ?>
			</select> 
		</div>
	</div>

	<div class="form-group">
		<label class="control-label col-sm-2" for="detailfield">Details<label data-toggle="tooltip" title="Write the details at every update"><font color="red">*</font></label>:</label>
		<div class="col-sm-10">	
			<textarea class="form-control" name="detailfield">What happenend exactly...?</textarea>		
		</div>
	</div>	

	<div class="form-group">
		<label class="control-label col-sm-2" for="detailfield">Image:</label>
		<div class="col-sm-10">	
			<input name="uploadimage" id="uploadimage" type="file">	
		</div>
	</div>	
	
	<div class="col-sm-offset-2 col-sm-10">
		<button type="submit" class="btn btn-primary btn-lg" name="submit" id="submit">Submit</button>
	</div>
	
</form>
</div>

<?php
$mysqli->close();
include_once('footer.php');
?>