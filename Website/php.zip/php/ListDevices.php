<?php
include_once('header.php');
?>
<title>See Devices</title>
<?php
include 'dbconnection.php';

$query = "SELECT * from dummmyLocRec";

if ($result = $mysqli->query($query)) {

?>
<center>
<h1>Device Details</h1><hr>

    <table class="table table-striped">
        <thead >
            <tr>
                <th>IP Address</th>
    		<th>Location</th>
		<th>Device ID</th>
		<th>  </th>
            </tr>

        </thead>
        <tbody>


    <?php
    while ($row = $result->fetch_assoc()) {

        ?>
        <tr>
            <td><?php echo $row["IPA"]; ?></td>
            <td><?php echo $row["Location"];  ?></td>
            <td><?php echo $row["DID"];  ?></td>
	    <td><a href="EditDevice.php?DID=<?php echo $row["DID"] ?>" class="btn btn-warning" role="button">Edit</a>
		<a href="DelDevice.php?DID=<?php echo $row["DID"] ?>&IPA=<?php echo $row["IPA"] ?>" class="btn btn-danger" role="button">Delete</a></td>
            
        </tr>
        <?php

    }
    ?>
        </tbody>
    </table>
</center>
    <?php
    $result->free();

}

/* close connection */
$mysqli->close();
/*<input type="button" value="Edit" onclick="window.location.href='EditDevice.php?DID=<?php echo $row["DID"] ?>'" />
<input type="button" value="Delete" onclick="window.location.href='DelDevice.php?DID=<?php echo $row["DID"] ?>&IPA=<?php echo $row["IPA"] ?>'" />
*/

include_once('footer.php');
?>
