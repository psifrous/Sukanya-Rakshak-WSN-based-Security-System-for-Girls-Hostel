
 <?php
include_once('header.php');	
?>
<head>
<title>Home</title>
<meta http-equiv="refresh" content="10" > 
</head>
<?php
include 'dbconnection.php';
	

$query = "SELECT * FROM IntruderLog";

if ($result = $mysqli->query($query)) {

 ?>
   
    
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Transaction #</th>
                <th>Location</th>
		<th>Date</th>
                <th>Time</th>
                <th>Escalated @</th>
		<th>Status</th>
		<th>On click</th>
            </tr>

        </thead>
        <tbody>


 <?php 
    while ($row = $result->fetch_assoc()) {
	$status=$row["Status"];
	if("Pending"==$status || "Esclate"==$status)
	{ 
		?>
		<tr>
			<td><?php echo $row["TID"]; ?></td>
            		<td><?php echo $row["Location"];  ?></td>
            		<td><?php echo $row["TDate"];  ?></td>
			<td><?php echo $row["TTime"];  ?></td>
            		<td><?php echo $row["ETime"];  ?></td>
            		<td><?php echo $status; ?></td>
            		<td><a href="UpdateLog.php?TID=<?php echo $row["TID"] ?>" class="btn btn-warning" role="button">Update</a></td>
		</tr>
	<?php
	}
    }
    ?>
        </tbody>
    </table>
    <?php
    $result->free();
}

/* close connection */
$mysqli->close();
/*<input type="button" value="Logs" onclick="window.location.href='SeeDetails.php'" />
<input type="button" value="See Devices" onclick="window.location.href='ListDevices.php'" /><br>
<input type="button" value="Update" onclick="window.location.href='UpdateLog.php?TID=<?php echo $row["TID"] ?>'" />
*/

include_once('footer.php');
?>

</div>