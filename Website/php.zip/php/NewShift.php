<?php
include 'dbconnection.php';

if($_POST){

	$guardname= $_POST['guardname'];
	$guardid= $_POST['guardid'];
	$shift= $_POST['shift'];
	$date= $_POST['gdate'];
	$location= $_POST['location'];
	$mobileno= $_POST['mobileno'];
	$emailid= $_POST['emailid'];
echo $mobile;
	$sql = "INSERT INTO `GuardLog` (`Name`,`GuardID`,`Shift`,`Date`,`Location`,`Mobile`,`EmailID`) VALUES ('$guardname','$guardid','$shift','$date','$location','$mobileno','$emailid')";
	if($mysqli->query($sql)){
		header("Location: NewShift.php");		
	}
	else{
		die('Invalid query: ' . mysqli_error());
	}	
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>New Shift</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
 
/* Set height of the grid so .sidenav can be 100% (adjust as needed) */
.row.content {height: 450px}
 
.sidenav {
padding-top: 20px;
background-color: #f1f1f1;
height: 100%;
}
 
footer {
background-color: #555;
color: white;
padding: 15px;
}
 
/* On small screens, set height to 'auto' for sidenav and grid */
@media screen and (max-width: 767px) {
.sidenav {
height: auto;
padding: 15px;
}
.row.content {height:auto;}
}
</style>
</head>
<body>
 <div class="container-fluid">
<nav class="navbar navbar-inverse">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="index.php">Sukanya Rakshak</a>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="SeeDetails.php">Logs</a></li>
      <li><a href="ListDevices.php">See Devices</a></li>
      <li><a href="AddDevice.php">Add Device</a></li>
      <li><a href="NewShift.php">New Shift</a></li>
      <li><a href="ListGuards.php">Guard Details</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
</ul>
</div>
</div>
</nav>
 <center>
<div style="background:#118888;color:white" class="jumbotron">
	<h2>Sukanya Rakshak </h2>
	<h4>Sukanya Rakshak </h4>
</div>
</center>


<div class="container-fluid text-center">

<center>
	<h1>Add a new Shift</h1>
	<h3>Enter Guards Detail for the Shift</h3>
<center>
</div>

<div class=container>
<form class="form-horizontal" method="POST" action="">
	<div class="form-group">
		<label class="control-label col-sm-2" for="guardname">Guard Name<label data-toggle="tooltip" title="Enter Guard's Full Name"><font color="red">*</font></label>:</label>
		<div class="col-sm-10">
    			<input type="text" name="guardname" class="form-control" id="guardname">		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="guardid">Guard ID<label data-toggle="tooltip" title="Enter Guard's ID Number"><font color="red">*</font></label>:</label>
		<div class="col-sm-10">
    			<input type="text" name= "guardid" class="form-control" id="guardid" >		
		</div>
	</div>
	
	<div class="form-group">
		<label class="control-label col-sm-2" for="shift">Shift<label data-toggle="tooltip" title="Select a Working Shift"><font color="red">*</font></label>:</label>
		<div class="col-sm-4">
			<select class="form-control" name=shift>
				<option value="None">-</option>
				<option value="Morning">Morning</option>
				<option value="Evening">Evening</option>
				
			</select> 
		</div>
	
		<label class="control-label col-sm-2" for="date">Date<label data-toggle="tooltip" title="Select Todays Date"><font color="red">*</font></label>:</label>
		<div class="col-sm-4">
    			<input type="date" name="gdate" class="form-control" id="gdate" >		
		</div>
	</div>
	
	<div class="form-group">
		<label class="control-label col-sm-2" for="location">Location<label data-toggle="tooltip" title="Enter the Guard's Posting Location"><font color="red">*</font></label>:</label>
		<div class="col-sm-10">
    			<input type="text" name="location" class="form-control" id="location" >		
		</div>
	</div>
	<div class="form-group">
		<label class="control-label col-sm-2" for="mobileno">Mobile No.<label data-toggle="tooltip" title="Enter Guard's Mobile No."><font color="red">*</font></label>:</label>
		<div class="col-sm-3">
    			<input type="text" maxlength="10" name="mobileno" class="form-control" id="mobileno" >		
		</div>
	
		<label class="control-label col-sm-2" for="emailid">Email ID<label data-toggle="tooltip" title="If No Email ID then set it to NONE"><font color="red">*</font></label>:</label>
		<div class="col-sm-5">	
			<input type="text" maxlength="50" name="emailid" class="form-control" id="emailid" >		
		</div>
	</div>	

		<div class="col-sm-offset-2 col-sm-10">
		<button type="submit"  class="btn btn-warning">Add New Guard</button>
	</div>
	
</form>

</div>
<br>
<?php
$mysqli->close();
include_once('footer.php');
?>